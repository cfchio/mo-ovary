======[ File description ]======
Datasets:
  chcsj_train_balanced_up.csv  --- Training set, balanced
  chcsj_train_imbal.csv        --- Training set, imbalanced
  chcsj_test.csv               --- Internal test set
  chcsj_2024.csv               --- Pseudo-prospective cohort
  kwh_ext.csv                  --- External validation cohort

Codes:
  features_selection.Rmd       --- Features selection, R markdown & HTML with output
  features_selection.html
  mo-ovary-train.ipynb         --- For training, Jupyter Notebook
  mo-ovary-evaluation.ipynb    --- For evaluation, Jupyter Notebook
  evaluation_n_visual.Rmd      --- Evaluation and visualization, R markdown & HTML with output
  evaluation_n_visual.html
  requirements.txt             --- For creating python environment

Data generated:
  result_test.csv              --- Prediction result of chcsj_test.csv
  result_pro.csv               --- Prediction result of chcsj_2024.csv
  result_ext.csv               --- Prediction result of kwh_ext.csv
  mo-ovary-23-01-sk132-vot.jb  --- Final model and relevant files
  mo-ovary-23-01-sk132-scaler.jb
  mo-ovary-23-01-sk132-mean.jb
  mo-ovary-23-01-sk132-shap.jb
  

======[ Create environment ]======
1. Create base environment with python 3.11
> conda create --name sk132 python=3.11

2. Install package
> conda activate sk132
> pip install -r requirements.txt
